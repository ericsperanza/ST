.. index:: QM/MM, Quantum

.. _con-qmmm:

Quantum Mechanics / Molecular Mechanics (QM/MM) Methods
=======================================================

Describe the theory underlying QM/MM

.. todo:: This page is to be completed by :ref:`developers-hlw`.

