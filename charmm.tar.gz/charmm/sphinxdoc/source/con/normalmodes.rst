.. index:: NMA, Normal Modes, Vibrational Frequencies

.. _con-normalmodes:

Normal Mode analysis
====================

Describe the theory underlying vibrational analysis

.. todo:: This page is to be completed by :ref:`developers-brb` and/or :ref:`developers-btm`.

