.. index:: Sampling, Monte Carlo

.. _con-sampling:

Sampling
========

Overview of the theory here.


.. _con-montecarlo:

Monte-Carlo
-----------


.. todo:: This page is to be completed by :ref:`developers-rjp` and/or :ref:`developers-vo`.

