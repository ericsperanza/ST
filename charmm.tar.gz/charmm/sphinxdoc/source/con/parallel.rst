.. index:: DOMDEC, Parallel

.. _con-parallel:

Parallelization
===============

Describe the theory underlying DOMDEC and parallelization

.. todo:: This page is to be completed by :ref:`developers-aph` and/or :ref:`developers-mc`.

