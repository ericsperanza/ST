.. _usr-basic-npt:

From PDB to NPT
===============

Running CHARMM dynamics in the isothermal-isobaric ensemble.
