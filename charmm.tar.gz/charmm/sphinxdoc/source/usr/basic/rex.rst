.. _usr-basic-rex:

Replica Exchange
================

Can be done with temperature, or pH, or Hamiltonians, or...
