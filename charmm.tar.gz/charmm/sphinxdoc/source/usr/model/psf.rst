.. _usr-model-psf:

Building the PSF
================

Input a sequence directly
-------------------------

Read a sequence from a file
---------------------------

Patch a sequence
----------------

Add hydrogens
-------------


