.. _usr-model-cg-primo:

PRIMO
=====

High resolution CG.
