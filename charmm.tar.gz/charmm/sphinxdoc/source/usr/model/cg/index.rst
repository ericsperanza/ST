.. _usr-model-cg:

Coarse Grained Models
=====================

What are they?

.. toctree::

   enm
   go
   primo
