.. _usr-simulation-freeenergy-nbb:

Non-Bennet Boltzmann
--------------------

This is one way of computing a free energy.
