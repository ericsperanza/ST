.. _usr-script-variable:

Variable Substitution and Retrivial
-----------------------------------
