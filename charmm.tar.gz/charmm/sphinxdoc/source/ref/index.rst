.. _ref-index:

Reference Manual
================

.. toctree::
   :maxdepth: 1

   select
   cmd/index
   file/index
