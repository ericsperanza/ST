.. index:: RTF, top, topology, residue

.. _ref-file-rtf:

Residue Topology File
=====================
