.. index:: PSF, structure, protein structure

.. _ref-file-psf:

Protein Structure File
======================
