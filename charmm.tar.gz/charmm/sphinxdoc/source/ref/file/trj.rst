.. index:: TRJ, DCD, trajectory, traj

.. _ref-file-trj:

Trajectory File
===============
