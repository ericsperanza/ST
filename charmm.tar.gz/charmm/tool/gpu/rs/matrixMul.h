#ifndef _MATRIXMUL_H_
#define _MATRIXMUL_H_

#define BLOCK_SIZE 16
//#define THD 64
#define THD 128     // best for gpucoulombforce_ij
//#define THD 256      // work
//#define THD 512

#endif // _MATRIXMUL_H_

