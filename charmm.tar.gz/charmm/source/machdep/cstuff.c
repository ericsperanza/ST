/* CHARMM Element source/machdep/cstuff.c */

/***********************************************************/
/* Try to implement this in fortran using C bindings       */
/* or use standard fortran routines directly if available. */
/* We need only these routines:                            */
/* system: why is it needed? why call system is not OK     */
/* getpwnam()->pw_dir - home directory from /etc/passwd    */
/* getpid()                                                */
/* getenv()                                                */
/* putenv()                                                */
/* getpwuid(),getlogin() - get username                    */
/* OUT::etime() - use fortran stuff, should be standard now!    */
/* time(),ctime() for fdate - use fortran!                 */
/* system() for csystem ??                                 */
/* Not needed::: gettimeofday() for xsecnds - used!                      */
/* uname(),gethostbyname() used for call uninf! we need!   */
/* - what to do with test endian (can we do it different?) */
/* - read namd: maybe replace by access='stream'           */
/*                                                         */
/***********************************************************/

/* include files */

#include <assert.h>
#include <ctype.h>
#include <stdio.h>
#include <signal.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>

#if MPI_OSX==YES
#include <sys/utsname.h>
#include <netdb.h>
#endif

#ifndef terra

#include <pwd.h>
#include <sys/param.h>
#include <sys/time.h>
#endif

#ifdef t3x
#include <sys/types.h>
#include <sys/times.h>
#include <stdio.h>
#include <pwd.h>
#endif

#if gnu || bgp
#include <time.h>
#include <sys/times.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/utsname.h>
#include <netdb.h>
#include <sys/file.h>
#include <sys/stat.h>
#endif

#if __convex__ || hpux || ibmrs || cray || machine_aix370 || VM || MVS || defined(machine_hp700)
#include <sys/file.h>
#include <sys/resource.h>
#include <sys/stat.h>
#if t3x || osx
#else
#include <sys/sysinfo.h>
#endif
#include <sys/times.h>
#include <sys/types.h>
#endif

#if cray || t3x
#include <fortran.h>
#include <unistd.h>
#include <time.h>	/* CLK_TCK */
#endif

#ifdef machine_titan
#include <sys/types.h>
#include <sys/times.h>
#endif

#if sgi
#define __stdc__
#include <sys/utsname.h>
#include <netdb.h>
#endif

#if hpux
/* #define machine_hp700 */
#undef __convex__  /* nedded for Convex Exemplar SPP-1000 */
#endif

#ifdef gnu
#undef hpux  /* This is for running GNU compilers on hpux */
#endif

#ifdef i8
#define INT long
#else 
#define INT int
#endif


/******************************************/
/*          start of generic code         */
/******************************************/

/******************** fmalloc *************/
// Commented out by APH 10/20/2014
/*
#if ibmrs || hpux || ether
char *fmalloc(reqlen)
#else

#if t3x
char *FMALLOC(reqlen)
#else
char *fmalloc_(reqlen)
#endif

#endif

unsigned INT *reqlen;
{
   return malloc(*reqlen);
} */   /* fmalloc_*/

/******************** free ****************/
// Commented out by APH 10/20/2014
/*
#ifdef ether
void ffree(address)
#else
void ffree_(address)
#endif
INT *address;
{ free(address); }
*/

/******************** fsystem *************/
/*

This function is better than system() because it does not
replicate program's memory requirements

*/
#ifndef terra
#if t3x
int FSYSTEM(char* com, INT* ll)
#else
#if hpux || ibmrs
int fsystem(char* com, INT* ll)
#else
INT fsystem_(char* com, INT* ll)
#endif
#endif
//     char *com ;
//     INT *ll;
{
  FILE *a ; char c;
  INT stat;

  com[*ll] = 0x0 ;
  /* AvdV Moved this to machutil.src so we can control it with prnlev
     printf("Invoking: %s\n",com); */
  if ( (a = popen(com,"r")) == NULL ) {
    printf("popen: Cannot create process\n") ;
    exit(-2) ;
  }
  /* Read the shell's stream and put it to the stdout*/
#if sgi
  while ( (c = getc(a) ) != '\377' ) putchar(c) ;
#else
  while ( (c = getc(a) ) != EOF ) putchar(c) ;
#endif
  /* Wait to finish with this command */
  stat=pclose(a) ;

  /* flush the stdout buffer to see the results
   * immediately instead of waiting till the end
   * of the CHARMM script
   */
  fflush(stdout);
  return(stat);
}
#endif /* terra */

/******************** gethdir *************/
#ifndef terra
#if t3x || cray
void GETHDIR(char *res, INT *len, char *env, INT *ll)
#else
#if hpux || ibmrs
void gethdir(char *res, INT *len, char *env, INT *ll)
#else
void gethdir_(char *res, INT *len, char *env, INT *ll)
#endif
#endif
//char *res, *env;
//INT *len, *ll;
{
  struct passwd *hdir ; char *tmp, *tmpenv; INT i;
/* Initialize result in case of error */
  *len = 0; res[0] = 0x0 ;
  tmpenv = malloc( *ll + 1) ;
  strncpy(tmpenv,env, *ll); tmpenv[*ll] = 0x0 ;
  hdir = getpwnam(tmpenv);
  tmp = hdir->pw_dir ;
/* If original string didn't match the username, try
   all lower case letters */
  if ( tmp == NULL ){
    for (i=0;i<strlen(tmpenv);i++)
      tmpenv[i] = tolower(tmpenv[i]) ;
    hdir = getpwnam(tmpenv); tmp = hdir->pw_dir ;
  }
  if ( tmp != NULL ){
    strcpy(res,tmp); i = strlen(res) ;
    res[i] = '/' ; i++ ;
    *len = i ;
  }

/*
  printf ("users %s home directory is %s\n",env, hdir->pw_dir);
  printf ("string is %d long\n",*len);
*/
}
#endif /* terra */

/******************** fgetpid *************/
#if t3x
void FGETPID(INT *pid)
#else
#if hpux || ibmrs
void fgetpid(INT *pid)
#else
void fgetpid_(INT *pid)
#endif
#endif
//INT *pid;
{
  *pid=getpid();
}

/******************** fgetenv *************/
#if t3x
void FGETENV(char *res, INT *len, char *env)
#else
#if hpux || ibmrs
void fgetenv(char *res, INT *len, char *env)
#else
void fgetenv_(char *res, INT *len, char *env)
#endif
#endif
//char *res, *env;
//INT *len;
{
  char *tmp, *getenv() ;
  *len = 0; res[0] = 0x0 ;
  tmp = getenv(env) ;
  if ( tmp != NULL ){
    strcpy(res,tmp);
    *len = strlen(res) ;
  }
/*  printf("strlen(fgetenv(%s)=%s)=%d\n",env,res,*len); */
}


/******************** fputenv *************/
#ifndef terra
#if cray || t3x
void FPUTENV(char env[],int t,INT *ll)
#else
#if hpux || ibmrs
void fputenv(char env[],INT *ll)
#else
void fputenv_(char env[],INT *ll)
#endif
#endif
//char env[];
//INT  *ll ;
#if t3x
//int t ;
#endif
{
  int i;
#if __convex__
  int p; char *nam, *val, *pp ;
  pp = strchr(env,'='); p = pp - env ;
  nam = malloc(*ll) ; val = malloc(*ll) ;
  strncat(nam,env,p) ; strcpy(val,&env[p+1]) ;
  nam[p] = 0x0 ; i = setenv(nam,val,1);
#else
#if t3x
  char *p ;
  /* Each call create new string to hold environment! */
  p = malloc(*ll) ; strncat(&p[0],env,*ll) ;
  i=putenv(p);
#else
  char *p ;
  /* Each call creates new string to hold environment! */
  p = malloc(*ll) ; strcpy(p,env) ;
  i=putenv(p);
#endif /* t3x */
#endif /* _convex_ */
  if(i != 0 ) {
    printf("fputenv=%d\n",i);
    perror("fputenv problem"); exit(110);
  }
}
#endif /* terra */

/******************** frealloc ************/
// Commented out by APH 10/20/2014
/*
char *frealloc_(ptr,reqlen)
char **ptr;
unsigned *reqlen;
{
   return realloc(*ptr,*reqlen);
//}    /* frealloc_*/

/******************** filcpy **************/
// Commented out by APH 10/20/2014
/*
void filcpy_(from,lfrom,to,lto,errint,nfrom,nto)
char *from,*to;
INT *lfrom,*lto,*errint;
INT nfrom,nto;
{
    char *tfrom,*tto;
    FILE *fpto,*fpfrom,*fopen();
/*    void fclose();  */
//    INT ch;

/* get memory for temporary file name strings */
//    if ( (tfrom = malloc(*lfrom + 1)) == NULL) {
//        printf("Error from malloc in filcpy (from)\n");
//        *errint = -1;
//        return;
//    }
//    if ( (tto = malloc(*lto + 1)) == NULL) {
//        printf("Error from malloc in filcpy (to)\n");
//        *errint = -1;
//        return;
//    }
/* now copy the strings and null terminate them. */
//    strncpy(tfrom,from,*lfrom);
//    tfrom[*lfrom] = '\0';
//    strncpy(tto,to,*lto);
//    tto[*lto] = '\0';
/* now open the files */
//    if( (fpto = fopen(tto,"w")) == NULL) {
//       printf("Error from fopen in filcpy (to)\n");
//       *errint = -1;
//       return;
//   }
//    if( (fpfrom = fopen(tfrom,"r")) == NULL) {
//       printf("Error from fopen in filcpy (from)\n");
//       *errint = -1;
//       return;
//    }
/* now actually copy the files */
//    while ( (ch = getc(fpfrom)) != EOF ) putc(ch,fpto);
/* now close the files, free the memory and return */
//    fclose(fpto);
//    fclose(fpfrom);
//    free(tto);
//    free(tfrom);
//    *errint = 0;
//    return;
//}    /* filcpy_*/

/*******************getunamef *************/
#ifndef terra
#if cray || defined(machine_titan) || t3x
void GETUNAMEF(char *name, INT *namelen)
#else
#if ibmrs || hpux
void getunamef(char *name, INT *namelen)
#else
void getunamef_(char *name, INT *namelen)
#endif
#endif
//    char        *name;
//    INT         *namelen;
{
    char        *getlogin();
/*    struct passwd *getpwuid(),*getpwptr; */
#ifndef __stdc__
    struct passwd *getpwuid(),*getpwptr;
#else
    struct passwd *getpwptr;
#endif
    char        *username;
    INT         usernamelen;

#if VM || MVS
    if ((username = COM_getusername()) == NULL) return;
#else
    if ((username = getlogin()) == NULL) {
       if ( (getpwptr = getpwuid(getuid())) == NULL) return;
       username = getpwptr->pw_name;
    }
#endif
    usernamelen = strlen(username);

    if(usernamelen > *namelen)
        usernamelen = *namelen;

    strncpy(name, username, usernamelen);

}    /* getunamef_*/
#endif /* terra */

/*******************  etime   *************/
#if ibmrs || hpux || cray || machine_aix370 || VM || MVS || defined(machine_hp700) || defined(machine_titan) || gnu || t3x

#if defined(machine_titan)
#define CLK_TCK HZ
#endif
/*
#if defined(CLOCKS_PER_SEC)     * fix for glibc-2.4 *
#define CLK_TCK CLOCKS_PER_SEC
#endif
*/
#if !defined(CLK_TCK)     /* fix for glibc-2.4 */
	extern long int __sysconf (int);
#   define CLK_TCK ((__clock_t) __sysconf (2))	/* 2 is _SC_CLK_TCK */
#endif

#if ibmrs
#include <time.h>
#endif

#if cray || t3x
float ETIME(float *tarray)
#else /* ibmrs || hpux ... */
#if gnu
float etime_obsolete_(float *tarray)
#else
float etime_obsolete(float *tarray)
#endif
#endif
//float *tarray;
{
   struct tms buffer;
   times(&buffer);
   tarray[0] = (double)(buffer.tms_utime)/CLK_TCK;
   tarray[1] = (double)(buffer.tms_stime)/CLK_TCK;
   return (tarray[0] + tarray[1]);
}    /* etime */
#endif

#if cray || t3x
void UNBUFIO(INT * unit)
#else
#if hpux || ibmrs
void unbufio(INT * unit)
#else
void unbufio_(INT * unit)
#endif
#endif
//INT * unit;
{ 
  setvbuf(stdout,(char *)0,_IONBF,0);
}

/*******************************************/
/*          end of generic code            */
/*          start of machine specific code */
/*******************************************/

// Commented out by APH 10/20/2014
/*
#ifdef t3x

#include <unistd.h>
int GET_CLK()
{
	return (sysconf(_SC_CLK_TCK));
}
int GET_MY_PE()
{
  extern long int _MPP_MY_PE;
  return (_MPP_MY_PE);
}
int GET_NUM_PES()
{
  extern long int _MPP_N_PES;
  return (_MPP_N_PES);
}
LOG2NPES(void)
{
        extern long int _MPP_LOG2_N_PES;
        return (_MPP_LOG2_N_PES);
}
void PSTART(int *inode,int *nodes)
//  int *inode, *nodes;
{
  extern long int _MPP_N_PES;
  extern long int _MPP_MY_PE;

  *nodes = _MPP_N_PES;
  *inode = _MPP_MY_PE;
  if (_MPP_MY_PE == 0){
    printf("PSTART: USING PVM3 \n");}
}

void FLUSH()
{
    fflush(stdout);
}

/***********************************************************************/
/*    shmem_get_f: shared memory get for fast communication            */
/*                                                                     */
/***********************************************************************/
/*
void SHMEM_GET_F(a,b,length,npe)
     int  istat;
     int *length,*npe;
     double a[],b[];
{
  istat =  shmem_get(a,b,*length,*npe);
}
*/
/***********************************************************************/
/*    shmem_put_f: shared memory get for fast communication            */
/*                                                                     */
/***********************************************************************/
/*
void SHMEM_PUT_F(a,b,length,npe)
     int  istat;
     int *length,*npe;
     double a[],b[];
{
  istat =  shmem_put(b,a,*length,*npe);
}
*/
//#endif /* t3x */

/*
#if terra

#include <Ttimelib.h>
#include <Tmdc.h>

int terra_date_time_(int* month,int *day, int* year,
                    int* hours,int *minutes, int* seconds)
{

time_t current_time;
struct tm current_broken_time;
int    rc;

       Ttime_time(&current_time);
       rc = gmtime_r(&current_time,&current_broken_time);

       *month =  current_broken_time.tm_mon;
       *day   =  current_broken_time.tm_mday;
       *year  =  current_broken_time.tm_year,
       *hours =  current_broken_time.tm_hour;
       *minutes = current_broken_time.tm_min;
       *seconds = current_broken_time.tm_sec;

       return(rc);
}

void
taskdelay_()
{
/*  taskDelay(sysClkRateGet() * 10); */
//  int i;
//  for (i=0;i<50000000;i++) i*i*i;
//}
//#endif /* terra */

#if __convex__
/***** getcpu *****/
void getcpu_(int *nthread,int *nthread_max)
{
/*     nthread: number of processors available to the process.
       nthread_max: hardware number of processors.
            nthread <= nthread_max.
*/
        struct  rlimit rlp;
        getrlimit(RLIMIT_CONCUR,&rlp);
        *nthread = rlp.rlim_cur;
        *nthread_max = rlp.rlim_max;
}    /* getcpu_*/

/***** setcpu *****/
int setcpu_(int *nthread)
{
        struct  rlimit rlp;

        getrlimit(RLIMIT_CONCUR,&rlp);
        if (*nthread > rlp.rlim_max) return -1;
        rlp.rlim_cur = *nthread;
        return setrlimit(RLIMIT_CONCUR,&rlp);
}    /* setcpu_*/

// Commented out by APH 10/20/2014
/***** setstk *****/
//void setstk_()
//{
/* set the stacksize to unlimited. */
//        struct  rlimit rlp;
//        getrlimit(RLIMIT_STACK,&rlp);
//        rlp.rlim_cur = RLIM_INFINITY;
//        setrlimit(RLIMIT_STACK,&rlp);
//        return;
//}    /* setstk_*/

// Commented out by APH 10/20/2014
/***** getsysinfo *****/
//int getsysinfo_(sn,type,ncpus)
//int *sn,*type,*ncpus;
//{       /* getsysinfo_ */
//    int                         i;
//    int                         bit;
//    time_t                              clock;
//    char                                hostname[132];
//    struct system_information   sysinfo;
//    extern int                  errno;
//
//    if ( getsysinfo(SYSINFO_SIZE, &sysinfo ) == -1 ) {
//        fprintf( stderr, "? getsysinfo failed: %d\n", errno );
//        return(1);
//    }
//
//    *sn = sysinfo.system_sn;
//    *type = sysinfo.cpu_type;
//    *ncpus = sysinfo.cpu_count;
//        return(0);
//
//}    /* getsysinfo_*/

// Commented out by APH 10/20/2014
/***** isecond *****/
//long isecond_()
//{
//   struct timeval tp;
//   struct timezone tzp;
//
//   if (gettimeofday(&tp,&tzp) != 0)
//       return 0;
//   else
//       return tp.tv_sec;
//}    /* isecond_*/

#endif

#if Alpha

/* we use the loc function provided by DU */
#else

#if ibmrs || defined(machine_aix370) || defined(machine_fujitsu) || VM || MVS || gnu
/***** loc *****/
#if machine_aix370 || gnu
int loc_(INT *numb)
#else
INT loc(INT *numb)
#endif
//INT *numb;
{
      return (INT) numb;
}    /* loc */
#endif

#endif

#if ibmrs || machine_aix370
/***** chdir_ *****/
#if ibmrs
#define DIR_LEN dir_len
#else /* machine_aix370 */
#define DIR_LEN *dir_len
#endif
INT chdir_(char *dir, INT dir_len)
//char *dir;
//INT  DIR_LEN;
{
        int i;
        char *cwd;
        INT result;

        /* get the directory name space */
        cwd = malloc(DIR_LEN+1);

        /* back scan the blanks out */
        for(i=DIR_LEN ; i==0 ;i--) {
                if(dir[i-1] != ' ') break;
        }

        /* copy that many characters and null terminate it */
        strncpy(cwd, dir, i);
        cwd[i] = '\0';

        /* call chdir */
        result = chdir(cwd);

        /* free the memory */
        free(cwd);

        /* tell the caller what happened */
        return(result);
}
#endif


#if hpux || ibmrs || machine_aix370 || VM || MVS || gnu
/***** fdate *****/
#if gnu
void fdate_(char *s)
#else
void fdate(char *s)
#endif
//char *s;
{
        char *ctime(), *c;
        time_t time(), t;

        t = time(0);
        c = ctime(&t);
        strncpy(s, c, 24);
}    /* fdate */

/***** itime
#if gnu
void itime_(timearray)
#else
void itime(timearray)
#endif
INT *timearray;
{
	struct tm *tp;
	time_t timer;

	time(&timer);
	tp = localtime(&timer);

	timearray[2] = tp->tm_sec;
	timearray[1] = tp->tm_min;
	timearray[0] = tp->tm_hour;
}     itime */
#endif

#if hpux
void cflush(FILE *out)
//FILE *out ;
{
  setbuf(out, NULL);
}
#endif

/***** chngbuf *****/
#if cray || defined(machine_titan)
void CHNGBUF(INT *lun,INT *pos,INT *error)
#elif gnu
void chngbuf(INT *lun,INT *pos,INT *error)
#elif __convex__ || unix || defined(machine_hp700)
void chngbuf_(INT *lun,INT *pos,INT *error)
#else
void chngbuf(INT *lun,INT *pos,INT *error)
#endif
{
   extern INT funits_fd();
   char *bufptr;
   *error = 0;
#if ! defined(machine_hp700) && ! defined(machine_titan)
   if (*lun == -1 || *lun == -2 || *lun == 6) {
       setlinebuf(stdout);
       return;
   }
   if (*lun == 0) {
       setlinebuf(stderr);
       return;
   }
#endif
   return;
/*
code is commmented out since it doesn't work.
however some of the stuff may be usefull for other
things. shf

   if ( (fd=funits_fd(*lun)) == -1) {
       *error = -1;
       return;
   }
*/
   /* now try to get type of file */
/*
   if ((flag = fcntl(fd,F_GETFL,0)) & O_RDONLY)
       return;
   else if ( flag & O_WRONLY )
       strcpy(type, "w");
   else if ( flag & O_RDWR )
       strcpy(type,"r+");
   else {
       *error = -1;
       return;
   }
   if ( (fp=fdopen(fd,type)) == NULL) {
       *error = -1;
       return;
   }
   printf("chgbuf_: pos: %d\n",*pos);
   if ( (bufptr = malloc(128)) == NULL) {
       *error = -1;
       return;
   }
   setbuffer(fp,bufptr,128);
   if (*pos > 0 ) fseek(fp,*pos,0);
*/
   /*setlinebuf(fp);*/
/*
   fprintf(fp,"chgbuf_: pos: %d\n",*pos);
   return;
*/
}    /* chngbuf_*/

#ifdef cray
#include <unistd.h>
void
GETCPU(int *ncpu, int *max_ncpu)
//   int  *ncpu;
//   int  *max_ncpu;
{
   char *env_value;
   extern long sysconf();
   char *getenv();

   *max_ncpu = sysconf(_SC_CRAY_NCPU);
   if (env_value = getenv("NCPUS")) {
      sscanf(env_value,"%d",ncpu);
      if (*ncpu < 1)
         fprintf(stderr,"Wrong NCPUS=%s\n",env_value);
   }
   else *ncpu=0;

   if (*ncpu > *max_ncpu)
      printf("You have asked for more processors than are physically available\n");
   if (*ncpu < 1 || *ncpu > *max_ncpu)
      *ncpu = *max_ncpu;
   printf("Will be using %d processor%s (maximum is %d)\n",
          *ncpu, ((*ncpu == 1) ? "" : "s"), *max_ncpu);
}

/***** numcpu *****/
/* Returns the number of physical processors on the system. */
NUMCPU()
{
        extern long sysconf();
        return(sysconf(_SC_CRAY_NCPU));
}

#endif

// Commented out by APH 10/20/2014
/*
#if defined(VM) || defined(MVS)
void ftxpwrt(message,len)
    char        *message;
    int         *len;
{
    char        *string;
    void        txpwrite();
    int         ii;

    if ((string = malloc((*len)+1)) == NULL)
       fprintf (stderr, "Error in ftxpwrt: no memory\n");
    else
    {
       for (ii=0; ii<*len; ii++)
          *(string+ii) = *(message+ii);
       *(string+ii) = '\0';
       txpwrite(string);
       free (string);
    }
    return;
}

void txpwrite(message)
    char        *message;
{
    fprintf(stderr, "%s\n", message); fflush(stderr);
}
#endif

#ifdef machine_hp700
chdir_(dir,len)
char *dir;
int len;
{
	chdir(dir,len);
}
#endif
*/

#if defined(cray) || defined(machine_aix370) || defined(VM) || defined(MVS)
void
#if defined(cray) || defined(VM) || defined(MVS)
#if defined(cray)
CSYSTEM(_fcd command,INT *cmdlen)
#else
CSYSTEM(char *command,INT *cmdlen)
#endif
#else
csystem_(char *command,INT *cmdlen)
#endif
//#if defined(cray)
//_fcd command;
//#else
//char *command;
//#endif
//INT  *cmdlen;
{
   char *cstring;
   INT   status;
   void  COM_tolower();

   if ((cstring = malloc(*cmdlen+1)) == NULL) {
      fprintf(stderr, "No memory for %d bytes in CSYSTEM\n", *cmdlen+1);
   }
   else {
#ifdef cray
      strncpy(cstring, _fcdtocp(command), *cmdlen);
#else
      strncpy(cstring, command, *cmdlen);
#endif
      cstring[*cmdlen] = '\0';
      if ((status = system(cstring)) != 0)
         fprintf(stderr, "command '%s' status=%d\n",cstring,status);
      free(cstring);
   }
   *cmdlen = 0;     /* nothing else to process in the command string */
}
#endif

// Commented out by APH 10/20/2014
/*
#if gnu || sgi || ibmrs
#if ibmrs
double xsecnds_obsolete(p)
#else
double xsecnds_obsolete_(p)
#endif
double *p ;
{
  struct timeval t; struct timezone tz; double r ;
  gettimeofday(&t, &tz) ;
  r = (double) t.tv_sec + (double) t.tv_usec / 1000000.0 ;
/*    printf("R = %f, P = %f\n", r, *p ) ; */
//  return ( r - *p ) ;
//}
//#endif

#ifdef ether

void getlog(char name[])
//char name[];
{
  char *getlogin() ;
  if ( (name = getlogin()) == NULL ) strcpy(name,"hp-par") ;
}

void setlinebuf(int i)
//int i ;
{
/* empty routine but it should flush buffer after each line
   is written on output
*/
}

#endif

// Commented out by APH 10/20/2014
/*
#if apollo
int ieor_(i,j)
int *i, *j ;
{
      return ( *i ^ *j ) ;
}
#endif
*/

// Now for everyone, not just gnu

#if KEY_PARCMD==1
//#if ibmrs
void uninf(char sy[],INT *l,char hn[],INT *lhn)
//#else
//void uninf_(char sy[],INT *l,char hn[],INT *lhn)
//#endif
//char sy[], hn[];
//INT *l, *lhn;
{
  struct hostent *h ;
  struct utsname inf ;
  char lsy[1000];
  int llhn,ll ;

  uname(&inf) ;
  if ( (h = gethostbyname(inf.nodename)) == NULL) {
    printf("gethostbyname>hostname problem: ");
    printf("check /etc/hosts or /etc/resolv.conf\n");
    sprintf(lsy,"%s-%s(%s)",
          inf.sysname,inf.release,inf.machine);
    *lhn = 0;
    if(hn != NULL) hn[0] = 0x0;
  } else {
    llhn = strlen(h->h_name) ; 
    *lhn = llhn ;
    *lhn = ( *lhn > 80 ) ? 80 : *lhn ;
    llhn = *lhn ;
    strncpy(hn,h->h_name,llhn);

    sprintf(lsy,"%s-%s(%s)@%s",
          inf.sysname,inf.release,inf.machine,h->h_name);
  }
  *l = strlen(lsy) ;
  *l = ( *l > 44 ) ? 44 : *l ;
  ll = *l ;
  strncpy(sy,lsy,ll);
}
#else
void uninf(char sy[],INT *l)
//char sy[];
//INT *l;
{
  struct hostent *h ;
  struct utsname inf ;
  char lsy[1000];
  int ll ;

  uname(&inf) ;

  if ( (h = gethostbyname(inf.nodename)) == NULL) {
    printf("gethostbyname>hostname problem: ");
    printf("check /etc/hosts or /etc/resolv.conf\n");
    sprintf(lsy,"%s-%s(%s)", inf.sysname, inf.release, inf.machine);
  } else {
    sprintf(lsy,"%s-%s(%s)@%s", inf.sysname, inf.release, inf.machine,
        h->h_name);
  }

  ll = strlen(lsy) ;
  *l = ll ;
  *l = ( *l > 44 ) ? 44 : *l ;
  ll = *l ;
  strncpy(sy,lsy,ll);
}
#endif

//Commented out by APH 10/20/2014
/*
#if gnu

unsigned INT ishft_(i,j)
INT *i, *j ;
{
  return ( ( *j > 0 ) ? *i << *j : *i >> *j ) ;
}

unsigned INT iand_(i,j)
     INT *i, *j ;
{
  return ( *i & *j ) ;
}

unsigned INT ior_(i,j)
     INT *i, *j ;
{
  return ( *i | *j ) ;
}
unsigned INT ieor_(i,j)
     INT *i, *j ;
{
  return ( *i ^ *j ) ;
}

/* empty routine but it should flush buffer after each line
   is written on output

   Commented out altogether IAW
*/
/*void setlinebuf(i)
FILE *i ;
{
}*/

//#endif

//Commented out by APH 10/20/2014
/*
#if altix
void malloc_()
{
  printf("malloc() not yet supported with Altix GNU compilers.\n");
}

void timef_()
{
  printf("timef() not yet supported with Altix GNU compilers.\n");
}
#endif
*/

#if TIMESTAMP

#define MAXSTAMP 100

static INT tzero, tpoint ;
static char stamptext[MAXSTAMP][80] ;


INT time_stamp_init__()
{
  struct tm *tm ; time_t tt ;
  time(&tt) ;
  tm = localtime(&tt) ;
  tpoint = 0 ;
  tzero = tm->tm_gmtoff ;
  return tm->tm_gmtoff ;
}


INT time_stamp__(INT *me, char *txt, INT *len)
{
  struct timeval t ; struct timezone z ;
  INT s ;
  gettimeofday( &t, &z );
  s = t.tv_sec ;
  s = (s+tzero) % 86400 ;
  if (tpoint < MAXSTAMP )
    {
      sprintf(stamptext[tpoint++],
	      "ME=%d;%02d:%02d:%02d.%06u %s %d\n",
	      *me, s / 3600, ( s % 3600 ) / 60, s % 60,
	      (unsigned long)t.tv_usec, txt, *len);
    }
  else printf("Time stamp memory exhausted\n");
}

#include <mpi.h>

INT flush_time_stamp__(INT *mynod, INT *numnod)
{
  /*
       This routine is complicated because it avoids overwriting
       from other nodes...
  */
  INT i,k,npoint;
  MPI_Status status ;
  char line[80] ;

  if (*mynod == 0)
    {
      for (i=0;i<tpoint;i++) printf("%s",stamptext[i]);
      for (k=1;k< *numnod;k++)
	{
	  MPI_Recv(&npoint,1,MPI_INT,k,1,MPI_COMM_WORLD,&status) ;
	  for (i=1;i<npoint;i++)
	    {
	      MPI_Recv(line,80,MPI_BYTE,k,1,MPI_COMM_WORLD,&status) ;
	      printf("%s",line);
	    }
	}
    }
  else
    {
      MPI_Send(&tpoint,1,MPI_INT,0,1,MPI_COMM_WORLD) ;
      for (i=0;i<tpoint;i++)
	MPI_Send(&stamptext[i],80,MPI_BYTE,0,1,MPI_COMM_WORLD) ;
    }

  return tpoint ;
}

#endif

/*
#ifdef SCHED
#include <sched.h>
void rtsched_(INT *statpri)
{
  struct sched_param p ;
  p.sched_priority = *statpri ;
  if ( sched_setscheduler(0, SCHED_FIFO, &p) == -1 )
    {
      perror("Kernel Real Time SCHED failed") ;
      exit(201);
    }
}
#endif
*/

#ifdef gnu_oldlib
/* This works only for old RadHat systems: */
/* floating point exception for x86-based GNU system */

#include <fpu_control.h>
void __attribute__ ((constructor))
trapfpe () {
   (void) __setfpucw (_FPU_DEFAULT &
                      ~(_FPU_MASK_IM | _FPU_MASK_ZM | _FPU_MASK_OM));
}
#endif


/*********************************************
           aag 06/07
           read/write binary namd file
 ********************************************/
#if ibmrs || hpux
void readnamd(double *x, double *y, double *z, INT *ptr_natom, char *fname, INT *ptr_flen, INT *ptr_ier)
#else
void readnamd_(double *x, double *y, double *z, INT *ptr_natom, char *fname, INT *ptr_flen, INT *ptr_ier)
#endif
{
  FILE *fp;
  int n, i; /* should not be INT since this can actually be long, not OK in the binary file */
  char *filename;

  /*  
      printf("size of INT is %d\n", (int)sizeof(INT));
      printf("size of double is %d\n", (int)sizeof(double));
  */
  
  /* allocate space for file names */
  if ( (filename = malloc(*ptr_flen + 1)) == NULL) {
    printf("Error from malloc in readnamd\n");
    *ptr_ier = -1;
    return;
  }
  /* now copy the strings and null terminate them. */
  strncpy(filename,fname,*ptr_flen);
  filename[*ptr_flen] = '\0';
  printf("opening file %s\n",filename); 
  if ( (fp = fopen(filename,"rb")) == NULL) {
    printf("could not open file %s\n",filename); 
    free(filename);
    *ptr_ier = -1;
    return;      
  }

  fread(&n, sizeof(int), 1, fp);

  /* checking if the number of atoms is the same */
  if (n != (*ptr_natom)) {
    printf("number of atoms does not match; in file %d, in psf %d ; exiting...\n",
          (int) n, (int) *ptr_natom);
    free(filename);
    *ptr_ier = -1;
    return;      
  }
  /* read in coordinates */
  for (i = 0; i < n; i++) {
    fread(x++,sizeof(double),1,fp);
    fread(y++,sizeof(double),1,fp);
    fread(z++,sizeof(double),1,fp);
  }
  fclose(fp);

  free(filename);
  *ptr_ier = 0;

}

#if ibmrs || hpux
void writenamd(double *x, double *y, double *z, INT *ptr_natom, char *fname, INT *ptr_flen, INT *ptr_ier)
#else
void writenamd_(double *x, double *y, double *z, INT *ptr_natom, char *fname, INT *ptr_flen, INT *ptr_ier)
#endif
{
  FILE *fp;
  int n, i;
  char *filename;

  /*  
      printf("size of INT is %d\n", (int)sizeof(INT));
      printf("size of double is %d\n", (int)sizeof(double));
  */
  
  /* allocate space for file names */
  if ( (filename = malloc(*ptr_flen + 1)) == NULL) {
    printf("Error from malloc in writenamd\n");
    *ptr_ier = -1;
    return;
  }
  /* now copy the strings and null terminate them. */
  strncpy(filename,fname,*ptr_flen);
  filename[*ptr_flen] = '\0';
  printf("opening file %s\n",filename); 
  if ( (fp = fopen(filename,"wb")) == NULL) {
    printf("could not open file %s\n",filename); 
    free(filename);
    *ptr_ier = -1;
    return;      
  }

  n = *ptr_natom;
  printf("saving number of atoms = %d\n", (int) n);
  fwrite(&n, sizeof(int), 1, fp);

  /* write in coordinates */
  for (i = 0; i < n; i++) {
    fwrite(x++,sizeof(double),1,fp);
    fwrite(y++,sizeof(double),1,fp);
    fwrite(z++,sizeof(double),1,fp);
  }
  fclose(fp);

  free(filename);
  *ptr_ier = 0;

}

/*********************************************
          osx_g95_getpointer
********************************************/

int osx_g95_getpointer__(double *a)
{
  return (int) a;
}

/* This is to fix Open MPI problem??? */
int openpty(void)
{
  printf("openpty>this should never be called.\n");
  return ENOENT;
}

/* #if bgl */
void flush()
{
    fflush(stdout);
}

// never used
#if 0
void uninf(char sy[],INT *l)
//char sy[];
//INT *l;
{
  struct hostent *h ;
  struct utsname inf ;
  char lsy[1000];

  uname(&inf) ;
  if ( (h = gethostbyname(inf.nodename)) == NULL) {
    printf("gethostbyname>hostname problem: ");
    printf("check /etc/hosts or /etc/resolv.conf\n");
    sprintf(lsy,"%s-%s(%s)",
          inf.sysname,inf.release,inf.machine);
  } else {
    sprintf(lsy,"%s-%s(%s)@%s",
          inf.sysname,inf.release,inf.machine,h->h_name);
  }
  *l = strlen(lsy) ;
  *l = ( *l > 44 ) ? 44 : *l ;
  strncpy(sy,lsy,*l);
}
#endif
// never used

/* #endif */

